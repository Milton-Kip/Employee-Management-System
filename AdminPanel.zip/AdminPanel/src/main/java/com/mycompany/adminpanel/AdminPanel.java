package com.mycompany.adminpanel;

/**
 *
 * @author Kipyegon M
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AdminPanel extends JFrame {
    private JTextField fullNameField;
    private JTextField contactInfoField;
    private JTextField positionField;
    private JTextField departmentField;
    private JComboBox<String> statusComboBox;
    private JTextArea employeeListArea;

    public AdminPanel() {
        setTitle("Employee Management System - Admin");
        setLayout(new GridBagLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Add padding between components

        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameField = new JTextField(20);

        JLabel contactInfoLabel = new JLabel("Contact Info:");
        contactInfoField = new JTextField(20);

        JLabel positionLabel = new JLabel("Position:");
        positionField = new JTextField(20);

        JLabel departmentLabel = new JLabel("Department:");
        departmentField = new JTextField(20);

        JLabel statusLabel = new JLabel("Status:");
        statusComboBox = new JComboBox<>(new String[]{"Pending Verification", "Verified"});

        JButton addButton = new JButton("Add Employee");
        JButton updateButton = new JButton("Update Employee");
        JButton deleteButton = new JButton("Delete Employee");

        employeeListArea = new JTextArea(10, 40);
        employeeListArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(employeeListArea);

        // Adding components to the panel using GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(fullNameLabel, gbc);

        gbc.gridx = 1;
        add(fullNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(contactInfoLabel, gbc);

        gbc.gridx = 1;
        add(contactInfoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(positionLabel, gbc);

        gbc.gridx = 1;
        add(positionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(departmentLabel, gbc);

        gbc.gridx = 1;
        add(departmentField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(statusLabel, gbc);

        gbc.gridx = 1;
        add(statusComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        add(addButton, gbc);

        gbc.gridy = 6;
        add(updateButton, gbc);

        gbc.gridy = 7;
        add(deleteButton, gbc);

        gbc.gridy = 8;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(scrollPane, gbc);

        // Button actions
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Employee newEmployee = new Employee(0, fullNameField.getText(), contactInfoField.getText(),
                        positionField.getText(), departmentField.getText(), (String) statusComboBox.getSelectedItem());
                EmployeeDAO.addEmployee(newEmployee);
                updateEmployeeList();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // In a real application, you should also provide a way to select employees to update
                // Here we just update the employee with ID 1 as an example
                Employee updatedEmployee = new Employee(1, fullNameField.getText(), contactInfoField.getText(),
                        positionField.getText(), departmentField.getText(), (String) statusComboBox.getSelectedItem());
                EmployeeDAO.updateEmployee(updatedEmployee);
                updateEmployeeList();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // In a real application, you should allow the admin to select an employee to delete
                // Here we delete employee with ID 1 as an example
                EmployeeDAO.deleteEmployee(1);
                updateEmployeeList();
            }
        });

        updateEmployeeList();
    }

    public void updateEmployeeList() {
        List<Employee> employees = EmployeeDAO.getAllEmployees("Pending Verification");
        StringBuilder sb = new StringBuilder();
        for (Employee employee : employees) {
            sb.append(employee.getFullName()).append(" - ").append(employee.getStatus()).append("\n");
        }
        employeeListArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminPanel().setVisible(true);
            }
        });
    }
}