package com.mycompany.adminpanel;

/**
 *
 * @author Kipyegon M
 */
public class Employee {
    private int id;
    private String fullName;
    private String contactInfo;
    private String position;
    private String department;
    private String status;

    public Employee(int id, String fullName, String contactInfo, String position, String department, String status) {
        this.id = id;
        this.fullName = fullName;
        this.contactInfo = contactInfo;
        this.position = position;
        this.department = department;
        this.status = status;
    }

    // Getters and Setters for the fields
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}